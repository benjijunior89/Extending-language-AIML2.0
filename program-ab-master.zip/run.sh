# java -cp lib/Ab.jar Main bot=alice2 action=chat trace=true morph=false
#java -cp lib/fichero.jar Main bot=alice2 action=chat trace=true morph=false
java -cp lib/Ab.jar Main bot=alice2 action=chat trace=true morph=false
